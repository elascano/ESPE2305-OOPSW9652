/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package espe.edu.ec.exam_01.model;

/**
 *
 * @author Juan Pasquel, The Encoders, DCCO-ESPE
 */
public class Building {
    private int id;
    private int numberOfRooms;
    private String owner;

    public Building(int id, int numberOfRooms, String owner, Object par3) {
        this.id = id;
        this.numberOfRooms = numberOfRooms;
        this.owner = owner;
    }

    @Override
    public String toString() {
        return "Building{" + "id=" + id + ", numberOfRooms=" + numberOfRooms + ", owner=" + owner + '}';
    }
    
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the room
     */
    public int getNumberOfRooms() {
        return numberOfRooms;
    }

    /**
     * @param numberOfRooms the room to set
     */
    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    /**
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }
    
    
}
