/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package espe.edu.ec.exam_01.view;

import espe.edu.ec.exam_01.model.Building;
import java.util.ArrayList;

/**
 *
 * @author Juan Pasquel, The Encoders, DCCO-ESPE
 */
public class Main {
    public static void main(String[] args) {
        Building building;
        ArrayList<Building>building1=new ArrayList<>();
        
    
    }
}
