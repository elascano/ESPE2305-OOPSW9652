/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package espe.edu.ec.exam_01.controller;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Juan Pasquel, The Encoders, DCCO-ESPE
 */
public class Menu {
    int option;
    public  int printMenu(){
        Scanner readOption = new Scanner(System.in);
        System.out.println("<----WELCOME TO PRINT BUILDINGS XD---->");
        System.out.println("What do you want to do ?");
        System.out.println("1.File Creation \n");
        System.out.println("2. Add Buildings\n");
        System.out.println("3. Print Buildings\n");
        System.out.println("4. Exit\n");
        option = readOption.nextInt();
        return option;
        try{
                System.out.println("Digit an option: ");
                option = scan.nextInt();

                switch (option) {
                    case 1:
                       
                        break;
                        
                    case 2:
                       
                        break;

                    case 3:
                        
                        break;

                    default:
                        System.out.println("Nonexistent option.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Incorrect dataType.");
                System.out.println("If you don't see the menu again.");
                System.out.println("Write any character and press enter.");
                scan.next();
            }
        }
    }

    
    
   