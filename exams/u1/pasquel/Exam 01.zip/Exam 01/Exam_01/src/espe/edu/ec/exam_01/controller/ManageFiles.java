/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package espe.edu.ec.exam_01.controller;

import Utils.nameException;
import Utils.idException;
import Utils.localNameException;
import espe.edu.ec.exam_01.model.Building;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Juan Pasquel, The Encoders, DCCO-ESPE
 */
public class ManageFiles {
    public static void createJsonFile(Scanner scan, ArrayList<Building> building) throws nameException, localNameException, idException {
        String fileName;
        int enter = 0;
        System.out.println(">>Ingress the name of the file you want to create: ");
        fileName = scan.next();
        do {
            enterStore(scan, building);
            enterStoreTwo(scan,  building);
            enterStoreThree(scan,  building);
            saveJsonFile(building, fileName);
        } while (enter == 1);
    }
    
}
 public static void enterBuilding (Scanner scan, ArrayList<Store> store)throws nameException{
        Store storeInfo = new Store();
        enterStoreData(scan, store);
        if("sssssss".equals(storeInfo.getName())){
            throw new nameException("That name doesn't exists");
        }
    }
    
    public static void enterStoreTwo(Scanner scan, ArrayList<Store> store) throws localNameException {
        Store storeInfo = new Store();
        enterStoreDataTwo(scan, store);
        if ("aaaaaaa".equals(storeInfo.getlocalName())) {
            throw new localNameException("That local name doesn't exists");
        }
    }
    
    public static void enterStoreThree(Scanner scan, ArrayList<Store> store) throws idException {
        Store storeInfo = new Store();
        enterStoreDataThree(scan, store);
        if (storeInfo.getId()!=10) {
            throw new idException("That id is incorrect because don't have 10 digits");
        }
    }